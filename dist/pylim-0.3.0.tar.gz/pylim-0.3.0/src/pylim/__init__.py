#!/usr/bin/env python
"""Init file for pylim a package designed to work with measurement data for the radiation group at LIM
author: Johannes Röttenbacher
"""

